import tkinter as tk
  
root=tk.Tk()
 
# setting the windows size
root.geometry("600x400")

# declaring string variable
rno_var=tk.StringVar()

def submit():
 
    rno=rno_var.get()
         
    print("The name is : " + rno)
    
    rno_var.set("")
    
# name using widget Label
rno = tk.Label(root, text = 'roll no', font=('calibre',10, 'bold'))
  
rno_entry = tk.Entry(root,textvariable = rno_var, font=('calibre',10,'normal'))


rno.grid(row=0,column=0)
rno_entry.grid(row=0,column=1)

root.mainloop()