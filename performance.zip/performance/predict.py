import pandas as pd


# Receive data from client
rno = 1
G1 = 0
G2 = 11
age = 18
Medu = 4
Fedu = 4
traveltime =2 
studytime = 2
failures = 0
famrel = 4
freetime =3 
goout = 4
health = 3
absences =4 

# Unpickle model
model = pd.read_pickle(r"C:\Users\sanje\Documents\python projects 2020\fisat\performance\XGBmodel.pkl")
print(model)
# Make prediction
result = model.predict(
    [[age, Medu, Fedu, traveltime, studytime, failures, famrel, freetime, goout, health, absences,G1,G2]])

classification = result[0]
print('G3 = ',classification)
# PredictionResults.objects.all().delete()
#PredictionResults.objects.create(rno=rno, grade_1=G1, grade_2=G2, age=age, mother_edu=Medu, father_edu=Fedu,
    #                                   travel_time=traveltime,
    #                                  study_time=studytime,
    #                                 failures=failures, fam_rel=famrel, free_time=freetime, go_out=goout,
    #                                health=health,
        #                               absences=absences,
        #                              grade_3=classification)
